
 = ;  = [System.Management.Automation.Language.Parser]::ParseFile('C:/Users/DAVID/Desktop/BridgeOS/bridge.ps1', [ref], [ref])
 = .FindAll({param()  -is [System.Management.Automation.Language.FunctionDefinitionAst]}, True)
 | ForEach-Object { .Name }
